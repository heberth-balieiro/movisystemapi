# Certifica API — Configurações da instituição

Pacote preparado para a API Delphi + Horse do projeto Certifica.

## Objetivo

Implementar os contratos já usados pelo frontend:

- PUT `configuracoes/instituicao`
- POST `configuracoes/instituicao/logo`
- POST `configuracoes/instituicao/banner`
- GET `configuracoes/whatsapp`
- PUT `configuracoes/whatsapp`
- GET público da mídia institucional

Use o mesmo prefixo que já existe no `Cursos.Routes`. No ambiente atual do frontend,
`NEXT_PUBLIC_API_URL` aponta para `http://192.168.15.10:9000/v1/certifica`, portanto
os caminhos acima são relativos a esse prefixo.

## Ordem de aplicação

1. Aplicar `patches/Cursos.Migration.patch.txt` no `Cursos.Migration.pas`.
2. Executar a API uma vez e validar a Migration 040.
3. Adicionar as units Model/DAO/Service/Controller/Security ao projeto Delphi.
4. Aplicar `patches/Cursos.Routes.patch.txt`.
5. Adicionar em `Config.ini` uma chave exclusiva para criptografar o token do WhatsApp.
6. Garantir que o diretório `uploads` tenha permissão de escrita no Linux/Windows.
7. Atualizar o endpoint público de instituição por slug para retornar:
   - `descricao`
   - `tema.banner_url`
   caso ele ainda não use o mesmo método `BuscarInstituicao`.

## Segurança

- `id_instituicao` vem exclusivamente do JWT assinado.
- O usuário precisa da permissão `configuracao.editar`.
- O token da Evolution API nunca é devolvido pela API.
- O token é armazenado criptografado usando `AES_ENCRYPT` do MySQL com chave fora do banco.
- A chave do WhatsApp NÃO deve ser a mesma chave do JWT.
- Logo/banner aceitam somente PNG/JPEG/WEBP com no máximo 5 MB.
- O nome físico do arquivo é gerado pela API e não usa o nome enviado pelo navegador.
- Toda consulta de configuração administrativa usa `id_instituicao`.

## Config.ini

Adicionar:

```ini
[SECURITY]
WhatsAppTokenSecret=COLOQUE_AQUI_UMA_CHAVE_ALEATORIA_DE_32_OU_MAIS_CARACTERES
```

Não versionar o `Config.ini` de produção.

## Observação sobre upload

O controller usa o multipart nativo do Horse:

```delphi
Req.ContentFields.Field('arquivo').AsStream
```

O stream pertence ao ciclo da request; não deve ser liberado pelo controller.
