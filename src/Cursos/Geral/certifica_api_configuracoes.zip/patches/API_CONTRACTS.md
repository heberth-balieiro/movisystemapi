# Contratos esperados pelo frontend

## PUT configuracoes/instituicao

Request:
```json
{
  "nome": "Horizonte Treinamentos",
  "razao_social": "Horizonte Treinamentos LTDA",
  "cnpj": "12345678000199",
  "descricao": "Instituicao...",
  "email": "contato@instituicao.com.br",
  "telefone": "11999999999",
  "site": "https://instituicao.com.br"
}
```

Response `dados`:
```json
{
  "id": 1,
  "slug": "horizonte-treinamentos",
  "nome": "Horizonte Treinamentos",
  "razao_social": "...",
  "cnpj": "...",
  "descricao": "...",
  "email": "...",
  "telefone": "...",
  "site": "...",
  "tema": {
    "nome_exibicao": "Horizonte Treinamentos",
    "logo_url": "...",
    "favicon_url": "...",
    "imagem_login_url": "...",
    "banner_url": "...",
    "cor_primaria": "#2563EB",
    "cor_secundaria": "#1E40AF",
    "cor_destaque": "#F59E0B",
    "cor_fundo": "#F8FAFC",
    "cor_texto": "#0F172A"
  }
}
```

## POST configuracoes/instituicao/logo
## POST configuracoes/instituicao/banner

`multipart/form-data`, campo obrigatório:
`arquivo`

Formatos: PNG/JPEG/WEBP
Máximo: 5 MB

Resposta: mesma instituição completa usada no PUT acima.

## GET configuracoes/whatsapp

```json
{
  "ativo": true,
  "url": "https://evolution.exemplo.com",
  "token_configurado": true,
  "token_mascarado": "********A1B2"
}
```

O token real nunca é retornado.

## PUT configuracoes/whatsapp

```json
{
  "ativo": true,
  "url": "https://evolution.exemplo.com",
  "token": "NOVO_TOKEN"
}
```

Em edição, `token` pode ser omitido ou vazio para preservar o token atual.
