unit InstituicaoConfiguracao.Controller;

interface

uses
  Horse,
  System.JSON;

type
  TInstituicaoConfiguracaoController = class
  private
    class procedure ExtrairClaims(
      const AReq: THorseRequest;
      out AIdInstituicao,
          AIdUsuarioInstituicao: Int64
    ); static;

    class function BaseUrl(
      const AReq: THorseRequest
    ): string; static;

    class function Envelope(
      const ADados: TJSONValue;
      const AMensagem: string = ''
    ): TJSONObject; static;

  public
    class procedure AtualizarInstituicao(
      Req: THorseRequest;
      Res: THorseResponse;
      Next: TProc
    ); static;

    class procedure UploadLogo(
      Req: THorseRequest;
      Res: THorseResponse;
      Next: TProc
    ); static;

    class procedure UploadBanner(
      Req: THorseRequest;
      Res: THorseResponse;
      Next: TProc
    ); static;

    class procedure BuscarWhatsApp(
      Req: THorseRequest;
      Res: THorseResponse;
      Next: TProc
    ); static;

    class procedure AtualizarWhatsApp(
      Req: THorseRequest;
      Res: THorseResponse;
      Next: TProc
    ); static;

    class procedure MidiaPublica(
      Req: THorseRequest;
      Res: THorseResponse;
      Next: TProc
    ); static;
  end;

implementation

uses
  System.SysUtils,
  System.Classes,
  System.JSON,
  App.Config,
  App.JWT,
  APP.Errors,
  InstituicaoConfiguracao.Model,
  InstituicaoConfiguracao.Service;

class procedure TInstituicaoConfiguracaoController.ExtrairClaims(
  const AReq: THorseRequest;
  out AIdInstituicao,
      AIdUsuarioInstituicao: Int64
);
var
  Config: TAppApiConfig;
  Token: string;
  Claims: TJWTClaims;
begin
  AIdInstituicao := 0;
  AIdUsuarioInstituicao := 0;

  Config :=
    TAppConfig.Carregar(
      ExtractFilePath(ParamStr(0)) +
      'Config.ini'
    );

  Token :=
    TAppJWT.ExtrairBearerToken(
      AReq.Headers['Authorization']
    );

  if not TAppJWT.ValidarEExtrair(
    Config.JWT,
    Token,
    Claims
  ) then
    TAppErrors.RaiseUnauthorized(
      'Token invalido ou expirado.'
    );

  if Claims.IdInstituicao <= 0 then
    TAppErrors.RaiseUnauthorized(
      'Instituicao nao identificada no token.'
    );

  if Claims.IdUsuarioInstituicao <= 0 then
    TAppErrors.RaiseUnauthorized(
      'Usuario da instituicao nao identificado no token.'
    );

  AIdInstituicao := Claims.IdInstituicao;
  AIdUsuarioInstituicao := Claims.IdUsuarioInstituicao;
end;

class function TInstituicaoConfiguracaoController.BaseUrl(
  const AReq: THorseRequest
): string;
var
  Proto: string;
  Host: string;
begin
  Proto := Trim(AReq.Headers['X-Forwarded-Proto']);
  Host := Trim(AReq.Headers['X-Forwarded-Host']);

  if Proto = '' then
    Proto := 'http';

  if Host = '' then
    Host := Trim(AReq.Host);

  Result := Proto + '://' + Host;
end;

class function TInstituicaoConfiguracaoController.Envelope(
  const ADados: TJSONValue;
  const AMensagem: string
): TJSONObject;
begin
  Result := TJSONObject.Create;
  Result.AddPair('erro', TJSONBool.Create(False));
  Result.AddPair('mensagem', AMensagem);

  if ADados <> nil then
    Result.AddPair('dados', ADados)
  else
    Result.AddPair('dados', TJSONNull.Create);
end;

class procedure TInstituicaoConfiguracaoController.AtualizarInstituicao(
  Req: THorseRequest;
  Res: THorseResponse;
  Next: TProc
);
var
  IdInstituicao: Int64;
  IdUsuarioInstituicao: Int64;
  Body: TJSONObject;
  Dados: TInstituicaoDadosInput;
  Retorno: TJSONObject;
begin
  ExtrairClaims(
    Req,
    IdInstituicao,
    IdUsuarioInstituicao
  );

  Body := Req.Body<TJSONObject>;

  if Body = nil then
    TAppErrors.RaiseBadRequest(
      'Body JSON nao informado.'
    );

  Dados := Default(TInstituicaoDadosInput);
  Dados.Nome := Body.GetValue<string>('nome', '');
  Dados.RazaoSocial := Body.GetValue<string>('razao_social', '');
  Dados.Cnpj := Body.GetValue<string>('cnpj', '');
  Dados.Descricao := Body.GetValue<string>('descricao', '');
  Dados.Email := Body.GetValue<string>('email', '');
  Dados.Telefone := Body.GetValue<string>('telefone', '');
  Dados.Site := Body.GetValue<string>('site', '');

  Retorno :=
    TInstituicaoConfiguracaoService.AtualizarInstituicao(
      IdInstituicao,
      IdUsuarioInstituicao,
      Dados
    );

  Res
    .Status(200)
    .Send<TJSONObject>(
      Envelope(
        Retorno,
        'Dados da instituicao atualizados.'
      )
    );
end;

class procedure TInstituicaoConfiguracaoController.UploadLogo(
  Req: THorseRequest;
  Res: THorseResponse;
  Next: TProc
);
var
  IdInstituicao: Int64;
  IdUsuarioInstituicao: Int64;
  Stream: TStream;
  Retorno: TJSONObject;
begin
  ExtrairClaims(
    Req,
    IdInstituicao,
    IdUsuarioInstituicao
  );

  if Req.ContentFields.Field('arquivo') = nil then
    TAppErrors.RaiseBadRequest(
      'Arquivo nao informado.'
    );

  Stream :=
    Req.ContentFields.Field('arquivo').AsStream;

  Retorno :=
    TInstituicaoConfiguracaoService.SalvarMidia(
      IdInstituicao,
      IdUsuarioInstituicao,
      'logo',
      BaseUrl(Req),
      Stream
    );

  Res
    .Status(200)
    .Send<TJSONObject>(
      Envelope(
        Retorno,
        'Logo atualizado.'
      )
    );
end;

class procedure TInstituicaoConfiguracaoController.UploadBanner(
  Req: THorseRequest;
  Res: THorseResponse;
  Next: TProc
);
var
  IdInstituicao: Int64;
  IdUsuarioInstituicao: Int64;
  Stream: TStream;
  Retorno: TJSONObject;
begin
  ExtrairClaims(
    Req,
    IdInstituicao,
    IdUsuarioInstituicao
  );

  if Req.ContentFields.Field('arquivo') = nil then
    TAppErrors.RaiseBadRequest(
      'Arquivo nao informado.'
    );

  Stream :=
    Req.ContentFields.Field('arquivo').AsStream;

  Retorno :=
    TInstituicaoConfiguracaoService.SalvarMidia(
      IdInstituicao,
      IdUsuarioInstituicao,
      'banner',
      BaseUrl(Req),
      Stream
    );

  Res
    .Status(200)
    .Send<TJSONObject>(
      Envelope(
        Retorno,
        'Banner atualizado.'
      )
    );
end;

class procedure TInstituicaoConfiguracaoController.BuscarWhatsApp(
  Req: THorseRequest;
  Res: THorseResponse;
  Next: TProc
);
var
  IdInstituicao: Int64;
  IdUsuarioInstituicao: Int64;
  Config: TInstituicaoWhatsAppConfig;
begin
  ExtrairClaims(
    Req,
    IdInstituicao,
    IdUsuarioInstituicao
  );

  Config :=
    TInstituicaoConfiguracaoService.BuscarWhatsApp(
      IdInstituicao,
      IdUsuarioInstituicao
    );

  Res
    .Status(200)
    .Send<TJSONObject>(
      Envelope(
        Config.ToJSON
      )
    );
end;

class procedure TInstituicaoConfiguracaoController.AtualizarWhatsApp(
  Req: THorseRequest;
  Res: THorseResponse;
  Next: TProc
);
var
  IdInstituicao: Int64;
  IdUsuarioInstituicao: Int64;
  Body: TJSONObject;
  Dados: TInstituicaoWhatsAppInput;
  Config: TInstituicaoWhatsAppConfig;
begin
  ExtrairClaims(
    Req,
    IdInstituicao,
    IdUsuarioInstituicao
  );

  Body := Req.Body<TJSONObject>;

  if Body = nil then
    TAppErrors.RaiseBadRequest(
      'Body JSON nao informado.'
    );

  Dados := Default(TInstituicaoWhatsAppInput);
  Dados.Ativo := Body.GetValue<Boolean>('ativo', False);
  Dados.Url := Body.GetValue<string>('url', '');
  Dados.Token := Body.GetValue<string>('token', '');

  Config :=
    TInstituicaoConfiguracaoService.AtualizarWhatsApp(
      IdInstituicao,
      IdUsuarioInstituicao,
      Dados
    );

  Res
    .Status(200)
    .Send<TJSONObject>(
      Envelope(
        Config.ToJSON,
        'Integracao com WhatsApp atualizada.'
      )
    );
end;

class procedure TInstituicaoConfiguracaoController.MidiaPublica(
  Req: THorseRequest;
  Res: THorseResponse;
  Next: TProc
);
var
  IdInstituicao: Int64;
  Caminho: string;
begin
  IdInstituicao :=
    StrToInt64Def(
      Req.Params['id'],
      0
    );

  Caminho :=
    TInstituicaoConfiguracaoService.ResolverMidiaPublica(
      IdInstituicao,
      Req.Params['tipo'],
      Req.Params['arquivo']
    );

  Res.SendFile(Caminho);
end;

end.
